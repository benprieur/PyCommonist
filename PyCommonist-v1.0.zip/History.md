* 20 avril 2021 : User:Benoît Prieur
  * ajout d'un fichier externe de configuration (largement inspiré par le code de User:Deansfa, merci à lui).
* 2 mai 2021 : User:Benoît Prieur
  * ajout d'une auto-suggestion des catégories (idée de User:Romainbar, merci à lui).
* 12 mai 2021 : User:Romainbar
  * support des adresses copiées depuis OSM
  * si la case des catégories par défaut est vide, la ligne n'est pas créée dans la page
  * ajout du code langue pour la description
* 14 mai 2021 : User:Romainbar
  * bouton pour modifier l'ordre de tri des images, entre nom de fichier (par défaut) et date Exif
  * transformation des cases à cocher en boutons pour les images à importer, et déplacement dans la frame de droite
  * case à cocher Import automatiquement à True quand on modifie le nom de l'image
* 31 mai 2021 : User:Romainbar
  * affichage du bon total des uploads réussis et ratés
* 2 juin 2021 : User:Romainbar
  * bouton pour recharger la liste des images à partir du dernier dossier sélectionné
* 12 juin 2021 : User:Romainbar
  * bouton pour copier et coller les nom, description et catégories d'une image à l'autre
  * possibilité d'incrémenter automatiquement le dernier numéro contenu dans le nom
* 13 juin 2021 : User:Romainbar
  * dialogue de confirmation d'upload quand aucune description ou aucune catégorie n'est entrée
  * décochage des images uploadées avec succès
* 6 décembre 2021 : User:Romainbar
  * affichage du nombre d'images traitées pendant l'upload
* 10 mai 2022 : User:Romainbar
  * affichage du nombre d'images prêtes à être importées dans le bouton d'import
* 28 mai 2022 : User:Benoît Prieur
  * reprise de la mise en forme selon PEP8 (pas parfait encore, pylint sous VS Code)
  * ajout d'une version de PyCommonist
  * augmentation de la largeur de l'auto-complétion
* 29 mai 2022 : User:Benoît Prieur
  * suite PEP8
  * contrôle de la non-utilisation du nom de fichier (localement et distant, sur Wikimedia Commons)