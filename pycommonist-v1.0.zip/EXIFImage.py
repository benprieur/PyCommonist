class EXIFImage:
    lat = None
    long = None
    heading = ''
    filename = ''
    date = ''
    time = ''
    full_file_path = ''
    